package com.artistapplication.network;

import android.util.Log;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    private static Retrofit retrofit;
    private static final String BASE_URL="http://ws.audioscrobbler.com/2.0/";
    //?method=album.search&album=believe&api_key=YOUR_API_KEY&format=json";

    public static AlbumDataService getService(){

        if (retrofit==null){
            retrofit=new Retrofit
                    .Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

        }

        return retrofit.create(AlbumDataService.class);
    }
}
