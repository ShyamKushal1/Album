package com.artistapplication.model;

import android.widget.ImageView;

import androidx.databinding.BindingAdapter;

import com.artistapplication.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Image {

@SerializedName("#text")
@Expose
private String text;
@SerializedName("size")
@Expose
private String size;

public String getText() {
return text;
}

public void setText(String text) {
this.text = text;
}

public String getSize() {
return size;
}

public void setSize(String size) {
this.size = size;
}

    @BindingAdapter("image")
    public static void loadImage(ImageView imageView, String imageURL) {
        Glide.with(imageView.getContext())
                .setDefaultRequestOptions(new RequestOptions()
                        .circleCrop())
                .load(imageURL)
                .placeholder(R.drawable.loading)
                .into(imageView);
    }

}