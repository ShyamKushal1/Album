package com.artistapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.SearchView;
import android.widget.Toast;

import com.artistapplication.adapter.DataAdapter;
import com.artistapplication.databinding.ActivityMainBinding;
import com.artistapplication.model.Album;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private MainViewModel mainViewModel;
    private DataAdapter dataAdapter;
    private ArrayList<Album> albumList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        ActivityMainBinding activityMainBinding = DataBindingUtil.setContentView(this,R.layout.activity_main);

        final SearchView searchView=activityMainBinding.searchView;


        RecyclerView recyclerView=activityMainBinding.viewData;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        mainViewModel= ViewModelProviders.of(this).get(MainViewModel.class);
        dataAdapter=new DataAdapter(this,albumList);
        recyclerView.setAdapter(dataAdapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String searchData) {

                if (checkNetwork()) {
                    getData(searchData);
                }
                else
                    Toast.makeText(MainActivity.this,"No Internet Connection",Toast.LENGTH_LONG).show();
                searchView.clearFocus();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });


    }

    private void getData(String searchData) {
        mainViewModel.getAllData(searchData).observe(this, new Observer<List<Album>>() {

            @Override
            public void onChanged(List<Album> albums) {
                //albumList.addAll(albums);
                dataAdapter.setAlbumList(albums);


            }
        });
    }

    private boolean checkNetwork(){
        boolean connection=false;

        ConnectivityManager connectivityManager= (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork=connectivityManager.getActiveNetworkInfo();

        if (activeNetwork!=null){
            if (activeNetwork.getType()==connectivityManager.TYPE_WIFI){
                connection=true;

            }
            if (activeNetwork.getType()==connectivityManager.TYPE_MOBILE){
                connection=true;

            }
        }
     return connection;
    }
}
