package com.artistapplication.model;


import android.widget.ImageView;

import androidx.databinding.BindingAdapter;

import com.artistapplication.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class AlbumDetailGetterSetter {


    //private String albumImage;
    private String albumName;
    private String albumArtist;
    private String albumUrl;

    /*public String getAlbumImage() {
        return albumImage;
    }

    public void setAlbumImage(String albumImage) {
        this.albumImage = albumImage;
    }*/

    public AlbumDetailGetterSetter(String albumName, String albumArtist, String albumUrl) {
        this.albumName = albumName;
        this.albumArtist = albumArtist;
        this.albumUrl = albumUrl;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getAlbumArtist() {
        return albumArtist;
    }

    public void setAlbumArtist(String albumArtist) {
        this.albumArtist = albumArtist;
    }

    public String getAlbumUrl() {
        return albumUrl;
    }

    public void setAlbumUrl(String albumUrl) {
        this.albumUrl = albumUrl;
    }

    @BindingAdapter("albumImage")
    public static void loadImage(ImageView imageView, String imageURL) {
        Glide.with(imageView.getContext())
                .setDefaultRequestOptions(new RequestOptions()
                        .circleCrop())
                .load(imageURL)
                .placeholder(R.drawable.loading)
                .into(imageView);
    }
}
