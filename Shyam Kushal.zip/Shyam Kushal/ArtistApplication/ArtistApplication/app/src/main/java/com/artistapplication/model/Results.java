package com.artistapplication.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Results {

@SerializedName("albummatches")
@Expose
private Albummatches albummatches;

public Albummatches getAlbummatches() {
return albummatches;
}

public void setAlbummatches(Albummatches albummatches) {
this.albummatches = albummatches;
}


}