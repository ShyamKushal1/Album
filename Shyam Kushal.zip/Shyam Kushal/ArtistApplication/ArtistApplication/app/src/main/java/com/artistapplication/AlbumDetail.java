package com.artistapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.artistapplication.databinding.ActivityAlbumDetailBinding;
import com.artistapplication.model.AlbumDetailGetterSetter;


public class AlbumDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_album_detail);
        ActivityAlbumDetailBinding activityAlbumDetailBinding=DataBindingUtil.setContentView(this,R.layout.activity_album_detail);
        Intent intent=getIntent();
        String image=intent.getStringExtra("image");
        String name=intent.getStringExtra("name");
        String artist=intent.getStringExtra("artist");
        String url=intent.getStringExtra("url");

        Log.i("album data",image+" "+name+" "+artist+" "+url);

        AlbumDetailGetterSetter albumDetailGetterSetter=new AlbumDetailGetterSetter(name,artist,url);

        activityAlbumDetailBinding.setAlbumDetail(albumDetailGetterSetter);
        activityAlbumDetailBinding.setImageProfile(image);


    }
}
