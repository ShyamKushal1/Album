package com.artistapplication.model;


import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.artistapplication.network.AlbumDataService;
import com.artistapplication.network.RetrofitClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AlbumRepository {

    //private ArrayList<Album> albums = new ArrayList<>();
    private MutableLiveData<List<Album>> mutableLiveData = new MutableLiveData<>();

    public MutableLiveData<List<Album>> getMutableLiveData(String searchData){

        final AlbumDataService albumDataService= RetrofitClient.getService();

        Call<AlbumResult> call=albumDataService.getResults(searchData);
        call.enqueue(new Callback<AlbumResult>() {
            @Override
            public void onResponse(Call<AlbumResult> call, Response<AlbumResult> response) {
                AlbumResult albumResult=response.body();
                if (albumResult!=null && albumResult.getResults()!=null){
                    mutableLiveData.setValue(albumResult.getResults().getAlbummatches().getAlbum());
                    List<Album> list=albumResult.getResults().getAlbummatches().getAlbum();
                    for (Album a :
                            list) {
                        Log.i("Album Artist Name",a.getArtist()+" "+a.getName());
                    }

                }
                Log.i("url ", String.valueOf(call.request().url()));
                Log.i("Success","successfully downloaded");
            }

            @Override
            public void onFailure(Call<AlbumResult> call, Throwable t) {
                Log.e("Error","Failed To Download");

            }
        });
        return mutableLiveData;
    }
}
