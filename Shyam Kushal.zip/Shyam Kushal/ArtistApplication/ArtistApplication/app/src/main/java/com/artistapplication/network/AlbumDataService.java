package com.artistapplication.network;


import android.util.Log;

import com.artistapplication.model.AlbumResult;
import com.artistapplication.model.Results;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface AlbumDataService {
    //?method=album.search&api_key=41a7dc63225fad49c47032141641b734&format=json&
    @GET("?method=album.search&api_key=41a7dc63225fad49c47032141641b734&format=json")
    Call<AlbumResult> getResults(@Query("album") String searchData);

}
