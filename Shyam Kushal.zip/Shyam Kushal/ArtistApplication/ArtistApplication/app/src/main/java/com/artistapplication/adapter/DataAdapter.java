package com.artistapplication.adapter;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.artistapplication.AlbumDetail;
import com.artistapplication.R;
import com.artistapplication.databinding.AlbumItemBinding;
import com.artistapplication.model.Album;
import com.artistapplication.model.Albummatches;
import com.artistapplication.model.Image;

import java.util.ArrayList;
import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.DataViewHolder> {

    private List<Album> albums;
    private Context context;

    public DataAdapter(Context context,List<Album> albums){
        this.context=context;
        this.albums=albums;
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        AlbumItemBinding albumItemBinding= DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.album_item, parent, false);

        return new DataViewHolder(albumItemBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {

        final Album album=albums.get(position);

        List<Image> list= album.getImage();
        for (Image i:
             list) {
            Log.i("NAme",album.getName()+album.getArtist()+" "+i.getText());
        }
        holder.albumItemBinding.setAlbum(album);
        holder.albumItemBinding.setImage(album.getImage().get(2));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context, AlbumDetail.class);
                intent.putExtra("image",album.getImage().get(2).getText());
                intent.putExtra("name",album.getName());
                intent.putExtra("artist",album.getArtist());
                intent.putExtra("url",album.getUrl());
                context.startActivity(intent);
            }
        });


    }

    public void setAlbumList(List<Album> albums) {
        this.albums = albums;

        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (albums != null) {
            return albums.size();
        } else {
            return 0;
        }

    }

    public class DataViewHolder extends RecyclerView.ViewHolder {

        private AlbumItemBinding albumItemBinding;

        public DataViewHolder(AlbumItemBinding albumItemBinding) {
            super(albumItemBinding.getRoot());
            this.albumItemBinding=albumItemBinding;
        }

    }
}
